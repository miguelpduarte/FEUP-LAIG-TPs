/**
 * PrimitiveObject
 * @constructor
 */
class PrimitiveObject extends CGFobject {
	constructor(scene) {
		super(scene);
	};

    setTexLengths(length_s, length_t) { }
};